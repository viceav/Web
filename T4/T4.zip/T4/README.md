# Process.js

No logré descifrar porqué los th:onclick me incluían las commillas del String
id, así que no me hice atao y lo solucioné con un replace en el javascript,
espero no importe mucho
