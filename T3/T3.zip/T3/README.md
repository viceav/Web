# Forms

Hola buenas, quería avisar que en los forms no me gustó el diseño que quedaba
cuando se usaba el atributo size, en todo caso en los archivos htmls si se
encuentra este atributo cada vez que lo piden, solo que con css cambié el width
de las cosas para que se viera más bonito

# Comentarios

También quería avisar que en los comentarios me hacía más sentido que estuviera
primero la opción de agregar comentarios (porque si fueran muchos comentarios
habría que bajar mucho para comentar). Así que dejé primero el agregar
comentarios y después la lista de los demás comentarios.

# Enlace a portada

Nada, sentí que ya le he dedicado mucho a la tarea entonces solo le puse un
enlace nomás, así que no está tan elegante. Espero no sea problema

# Uso de fetch

Hice uso de fetch para poder obtener la información del json, así que habría que
usar un live server para que la información de las regiones y las comunas se
obtenga.

# Colores oscuros

Estoy acostumbrado a usar modo oscuro, así que srry si molesta un poco la
elección de colores.

# Importación de librerías

`pip install -r requirements.txt`
